import React from 'react'

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">
            Welcome to Your React App
          </h1>
          <p className="text-xl text-gray-600">
            Built with Vite, React, TypeScript, and Tailwind CSS
          </p>
        </header>
        
        <main className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
              <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                🚀 Fast Development
              </h2>
              <p className="text-gray-600">
                Lightning-fast development experience with Vite's hot module replacement
                and optimized build process.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
              <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                💪 Type Safety
              </h2>
              <p className="text-gray-600">
                Built with TypeScript for better code quality, enhanced developer
                experience, and fewer runtime errors.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
              <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                🎨 Beautiful Styling
              </h2>
              <p className="text-gray-600">
                Tailwind CSS provides utility-first styling for rapid UI development
                with consistent design patterns.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
              <h2 className="text-2xl font-semibold text-gray-800 mb-4">
                📱 Responsive Design
              </h2>
              <p className="text-gray-600">
                Mobile-first responsive design ensures your app looks great on all
                devices and screen sizes.
              </p>
            </div>
          </div>
          
          <div className="text-center">
            <button className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-8 rounded-lg transition-colors shadow-lg hover:shadow-xl">
              Get Started
            </button>
          </div>
        </main>
      </div>
    </div>
  )
}

export default App