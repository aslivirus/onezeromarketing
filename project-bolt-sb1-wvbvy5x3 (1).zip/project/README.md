# Manual Deployment Instructions

## For Hostinger or any Static Hosting Provider

### Step 1: Build the Project Locally

1. Make sure you have Node.js installed (version 16 or higher)
2. Open terminal/command prompt in the project folder
3. Install dependencies:
   ```bash
   npm install
   ```
4. Build the project:
   ```bash
   npm run build
   ```

This will create a `dist` folder with all the static files.

### Step 2: Upload to Hostinger

1. Log into your Hostinger control panel
2. Go to File Manager
3. Navigate to your domain's public_html folder
4. Upload all files from the `dist` folder to public_html
5. Your site should now be live!

### Alternative: Using FTP

1. Use an FTP client like FileZilla
2. Connect to your Hostinger FTP
3. Upload all files from the `dist` folder to the public_html directory

### For Other Free Hosting Providers

**Netlify (Free):**
1. Go to netlify.com
2. Drag and drop the `dist` folder
3. Your site is live instantly!

**Vercel (Free):**
1. Go to vercel.com
2. Import your project from GitHub or upload the `dist` folder
3. Deploy with one click

**GitHub Pages (Free):**
1. Push your code to a GitHub repository
2. Go to repository Settings > Pages
3. Select source branch and folder
4. Your site will be available at username.github.io/repository-name

### Important Notes

- Always upload the contents of the `dist` folder, not the folder itself
- Make sure index.html is in the root directory of your hosting
- For custom domains, update your DNS settings in your domain registrar
- The built files are optimized and minified for production use